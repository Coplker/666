
Add-Type -AssemblyName System.Windows.Forms while ($true) {
$b= New-Object
System.Drawing.Bitmap([System.Windows.Forms.Screen]:: PrimaryScreen. Bounds.Width,
[System.Windows.Forms.Screen]:: PrimaryScreen. Bounds.Height)
-
$g [System.Drawing.Graphics]:: FromImage($b)
$g.CopyFromScreen(0,0,0,0, b.Size)
L
$path = "$env: TMP\ghost.png"
$b.Save($path, [System.Drawing.Imaging.ImageFormat]:: Png)
Set-ItemProperty -Path 'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies \Explorer -Name 'NoDesktop' -Value 1
Add-Type -TypeDefinition @"
using System.Runtime.InteropServices;
public class W { [DllImport("user32.dll")] public static extern bool SystemParametersInfo(int a,int b,string c,int d); }
"@
}
[W]::SystemParameters Info (20,0, $path, 3) Start-Sleep 30